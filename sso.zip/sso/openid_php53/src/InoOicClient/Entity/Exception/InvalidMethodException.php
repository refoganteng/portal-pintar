<?php

namespace InoOicClient\Entity\Exception;


class InvalidMethodException extends \RuntimeException
{
}