<?php

namespace InoOicClient\Json\Exception;


class DecodeException extends \RuntimeException
{
}