<?php

namespace InoOicClient\Flow\Exception;


class UserInfoRequestException extends \RuntimeException
{
}