<?php

namespace InoOicClient\Flow\Exception;


class AuthorizationException extends \RuntimeException
{
}