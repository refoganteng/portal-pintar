<?php

namespace InoOicClient\Flow\Exception;


class TokenRequestException extends \RuntimeException
{
}