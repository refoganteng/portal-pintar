<?php

namespace InoOicClient\Client\Authenticator\Exception;


class UnsupportedAuthenticationMethodException extends \RuntimeException
{
}