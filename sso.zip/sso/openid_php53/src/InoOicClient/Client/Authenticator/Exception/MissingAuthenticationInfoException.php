<?php

namespace InoOicClient\Client\Authenticator\Exception;


class MissingAuthenticationInfoException extends \RuntimeException
{
}