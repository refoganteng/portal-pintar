<?php

namespace InoOicClient\Oic\Authorization\Exception;


class MissingStateManagerException extends \RuntimeException
{
}