<?php

namespace InoOicClient\Oic\Authorization\Exception;


class StateException extends \RuntimeException
{
}