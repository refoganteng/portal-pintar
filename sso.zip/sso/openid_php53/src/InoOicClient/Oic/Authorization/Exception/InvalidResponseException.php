<?php

namespace InoOicClient\Oic\Authorization\Exception;


class InvalidResponseException extends \RuntimeException
{
}