<?php

namespace InoOicClient\Oic\Authorization\Uri\Exception;


class MissingEndpointException extends \RuntimeException
{
}