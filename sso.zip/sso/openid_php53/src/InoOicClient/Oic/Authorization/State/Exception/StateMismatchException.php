<?php

namespace InoOicClient\Oic\Authorization\State\Exception;


class StateMismatchException extends \RuntimeException
{
}