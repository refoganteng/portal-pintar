<?php

namespace InoOicClient\Oic\Authorization\State\Exception;


class InvalidLocalStateException extends \RuntimeException
{
}