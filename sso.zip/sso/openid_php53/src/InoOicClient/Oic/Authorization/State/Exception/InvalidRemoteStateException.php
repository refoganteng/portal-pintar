<?php

namespace InoOicClient\Oic\Authorization\State\Exception;


class InvalidRemoteStateException extends \RuntimeException
{
}