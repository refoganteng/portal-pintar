<?php

namespace InoOicClient\Oic\UserInfo\Exception;


class InvalidResponseException extends \RuntimeException
{
}