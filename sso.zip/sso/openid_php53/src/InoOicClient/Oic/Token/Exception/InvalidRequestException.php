<?php

namespace InoOicClient\Oic\Token\Exception;


class InvalidRequestException extends \RuntimeException
{
}