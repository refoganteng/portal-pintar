<?php

namespace InoOicClient\Oic\Token\Exception;


class HttpErrorResponseException extends \RuntimeException
{
}