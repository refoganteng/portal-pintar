<?php

namespace InoOicClient\Oic\Token\Exception;


class InvalidResponseException extends \RuntimeException
{
}