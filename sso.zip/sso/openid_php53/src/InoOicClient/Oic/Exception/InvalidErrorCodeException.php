<?php

namespace InoOicClient\Oic\Exception;


class InvalidErrorCodeException extends \RuntimeException
{
}