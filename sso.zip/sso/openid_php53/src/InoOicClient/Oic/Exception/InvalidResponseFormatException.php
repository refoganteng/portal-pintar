<?php

namespace InoOicClient\Oic\Exception;


class InvalidResponseFormatException extends \RuntimeException
{
}