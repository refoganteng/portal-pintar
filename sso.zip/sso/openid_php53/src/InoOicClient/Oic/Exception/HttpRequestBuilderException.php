<?php

namespace InoOicClient\Oic\Exception;


class HttpRequestBuilderException extends \RuntimeException
{
}