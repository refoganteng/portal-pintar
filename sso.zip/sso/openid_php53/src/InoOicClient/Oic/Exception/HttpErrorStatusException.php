<?php

namespace InoOicClient\Oic\Exception;


class HttpErrorStatusException extends \RuntimeException
{
}