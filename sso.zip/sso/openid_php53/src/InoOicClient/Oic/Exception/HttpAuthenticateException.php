<?php

namespace InoOicClient\Oic\Exception;


class HttpAuthenticateException extends \RuntimeException
{
}