<?php

namespace InoOicClient\Oic\Exception;


class HttpClientException extends \RuntimeException
{
}