<?php
require __DIR__ . '/../init_autoload.php';

define('TESTS_ROOT', __DIR__);